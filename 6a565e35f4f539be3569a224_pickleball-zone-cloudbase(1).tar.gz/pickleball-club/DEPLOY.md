# Pickleball Zone Club 部署说明

## 环境要求
- Node.js >= 18.0.0
- npm >= 9.0.0

## 本地启动

```bash
# 1. 安装依赖
cd server && npm install

# 2. 初始化数据库（首次运行）
node db.js

# 3. 启动服务器
node index.js
# 或开发模式（自动重启）
node --watch index.js
```

服务器将在 http://localhost:3000 启动。

## 默认账号

| 角色 | 用户名 | 密码 |
|------|--------|------|
| 管理员 | admin | admin123 |
| 演示会员 | demo | demo123 |

## 页面路由

| 路径 | 说明 |
|------|------|
| / | 首页 |
| /login | 会员/管理员登录 |
| /register | 会员注册 |
| /member | 会员中心 |
| /member/activities | 活动报名 |
| /member/rewards | 积分兑换 |
| /admin | 管理后台 |

## 部署到生产环境

### 方案一：直接部署（VPS/云服务器）

```bash
# 1. 上传代码到服务器
# 2. 安装依赖
cd server && npm install --production

# 3. 初始化数据库
node db.js

# 4. 使用 PM2 守护进程
npm install -g pm2
pm2 start index.js --name pickleball-zone
pm2 save
pm2 startup

# 5. 配置 Nginx 反向代理
```

Nginx 配置示例：
```nginx
server {
    listen 80;
    server_name your-domain.com;

    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_cache_bypass $http_upgrade;
    }

    # 限制上传文件大小
    client_max_body_size 10M;
}
```

### 方案二：Docker 部署

```dockerfile
FROM node:20-alpine
WORKDIR /app
COPY server/package*.json ./server/
RUN cd server && npm install --production
COPY . .
RUN cd server && node db.js
EXPOSE 3000
CMD ["node", "server/index.js"]
```

```bash
docker build -t pickleball-zone .
docker run -d -p 3000:3000 --name pzclub pickleball-zone
```

### 方案三：Railway / Render 等PaaS平台

1. 推送代码到 GitHub
2. 在平台创建新项目，连接仓库
3. 设置 Build Command: `cd server && npm install`
4. 设置 Start Command: `cd server && node index.js`
5. 设置环境变量（可选）: `PORT=3000`
6. 部署

## 安全建议（生产环境必做）

1. **修改管理员密码**：登录后台后通过数据库或添加修改密码功能
2. **更换 JWT 密钥**：在 `server/middleware/auth.js` 中修改 `JWT_SECRET`
3. **启用 HTTPS**：通过 Nginx + Let's Encrypt 配置 SSL 证书
4. **限制上传文件大小**：已在代码中设置 10MB 限制
5. **定期备份数据库**：`cp server/data.db backup/data_$(date +%Y%m%d).db`

## 技术栈

- **前端**：原生 HTML/CSS/JavaScript（无框架依赖）
- **后端**：Node.js + Express
- **数据库**：SQLite (better-sqlite3)
- **认证**：JWT (jsonwebtoken)
- **密码**：bcryptjs
- **文件上传**：multer