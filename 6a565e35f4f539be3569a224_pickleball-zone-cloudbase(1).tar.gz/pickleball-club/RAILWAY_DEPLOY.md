# Pickleball Zone — Railway 小白部署指南

> 本指南面向零基础用户，每一步都有详细说明。跟着做，10 分钟内你的网站就能上线。

---

## 你需要准备什么？

只需要两样东西，都是免费的：

1. **GitHub 账号** — 用来存放代码（类似网盘，但专门放代码）
   - 没有的话去 [github.com](https://github.com) 注册，用邮箱就行

2. **Railway 账号** — 用来部署网站（免费的云服务器）
   - 去 [railway.app](https://railway.app) 注册，可以直接用 GitHub 账号登录

---

## 第一步：把代码推送到 GitHub

### 1.1 创建 GitHub 仓库

1. 打开 [github.com](https://github.com)，登录你的账号
2. 点击页面右上角的 **"+"** 按钮，选择 **"New repository"**
3. 填写仓库信息：
   - **Repository name**: `pickleball-zone` （随便你取什么名字）
   - **Description**: `Pickleball Zone Club 潮玩运动俱乐部网站` （可选）
   - **Public** / **Private**: 选 **Public**（免费且方便）
   - **Initialize this repository with**: **什么都不勾选**（留空）
4. 点击最下面的绿色按钮 **"Create repository"**

> 创建成功后，页面会跳转到新仓库，你会看到一个类似 `https://github.com/你的用户名/pickleball-zone` 的网址。

### 1.2 上传代码

**方法一：用 Git 命令（推荐，学会后以后很方便）**

打开电脑的「终端」或「命令提示符」，依次输入以下命令（每行按回车）：

```bash
# 1. 进入项目文件夹（根据你解压的位置修改路径）
cd /Users/你的用户名/Downloads/pickleball-club

# 2. 初始化 Git 仓库
git init

# 3. 添加所有文件
git add .

# 4. 提交（写一句说明）
git commit -m "Initial commit"

# 5. 连接到你的 GitHub 仓库
# 注意：把下面的 "你的用户名" 换成你的 GitHub 用户名
git remote add origin https://github.com/你的用户名/pickleball-zone.git

# 6. 推送到 GitHub
git branch -M main
git push -u origin main
```

> 第 6 步会要求你输入 GitHub 的用户名和密码。**注意：密码不是你的登录密码，而是 "Personal Access Token"（个人访问令牌）。**
>
> 获取方法：GitHub 页面 → 右上角头像 → Settings → 左侧最下面 Developer settings → Personal access tokens → Tokens (classic) → Generate new token → 勾选 "repo" → Generate → 复制生成的 token 作为密码使用。

**方法二：直接网页上传（最简单，不用学 Git）**

1. 在刚才创建的 GitHub 仓库页面，点击 **"uploading an existing file"** 链接
2. 点击 **"choose your files"**，选择你电脑上解压后的 `pickleball-club` 文件夹里的所有文件和子文件夹
   - 注意：需要展开 `_shared/fonts/`、`assets/`、`server/routes/`、`server/middleware/`、`server/uploads/` 这些子文件夹，把里面的文件也一起选上
3. 页面底部写一句提交说明：`Initial commit`
4. 点击 **"Commit changes"**

> 网页上传的缺点：一次只能上传最多 100 个文件，且子文件夹需要单独处理。如果文件很多，建议用方法一。

### 1.3 确认上传成功

回到你的 GitHub 仓库页面 `https://github.com/你的用户名/pickleball-zone`，应该能看到所有文件了，包括：
- `pickleball-club.html`（首页）
- `login.html`、`register.html`、`member.html` 等页面
- `server/` 文件夹（后端代码）
- `assets/` 文件夹（图片）
- `_shared/fonts/` 文件夹（字体）
- `railway.json`（Railway 配置文件）

---

## 第二步：在 Railway 上部署

### 2.1 登录 Railway

1. 打开 [railway.app](https://railway.app)
2. 点击 **"Get Started"** 或 **"Login"**
3. 选择 **"Continue with GitHub"**，用你的 GitHub 账号登录

### 2.2 创建新项目

1. 登录后，点击 **"New Project"**
2. 选择 **"Deploy from GitHub repo"**
3. 如果你第一次用，可能需要点击 **"Configure GitHub App"** 授权 Railway 访问你的 GitHub 仓库
4. 在列表中找到并选择你的仓库：`pickleball-zone`
5. 点击 **"Add"**

### 2.3 配置部署设置

Railway 会自动识别这是一个 Node.js 项目。现在需要确认/修改几个设置：

1. 在项目页面，点击左侧的 **"Settings"**（齿轮图标）
2. 找到 **"Deployments"** 部分：
   - **Start Command**: 确认是 `cd server && node index.js`
   - **Root Directory**: 保持默认（`.` 表示根目录）
3. 如果 Start Command 不对，手动修改为：`cd server && node index.js`

> 项目已经包含了 `railway.json` 配置文件，Railway 通常会自动读取这个配置，你大概率不需要手动改任何东西。

### 2.4 部署

1. 回到项目主页（点击左上角的「方块」图标）
2. 点击绿色的 **"Deploy"** 按钮（如果没有自动开始部署的话）
3. 等待 1-3 分钟，你会在页面上看到部署日志滚动
4. 当状态变为 **"Healthy"**（绿色）时，表示部署成功！

### 2.5 获取公开网址

1. 在项目页面，点击左侧的 **"Settings"**
2. 找到 **"Environment"** 或 **"Domains"** 部分
3. 你会看到一个类似 `pickleball-zone-production-xxxx.up.railway.app` 的网址
4. 点击旁边的 **"Copy"** 复制链接，这就是你的公开网址！

> 这个网址全世界都能访问，发给朋友他们也能打开。

---

## 第三步：验证网站

把复制的网址粘贴到浏览器地址栏，按回车。你应该能看到：

1. **首页** (`/`) — 显示 Paddletek 球员、PPA Asia 赛事等内容
2. **登录页** (`/login`) — 会员和管理员都能登录
3. **注册页** (`/register`) — 新会员注册
4. **会员中心** (`/member`) — 登录后查看积分、签到、参加活动
5. **管理后台** (`/admin`) — 管理员登录后管理内容

### 默认测试账号

| 角色 | 用户名 | 密码 |
|------|--------|------|
| 管理员 | admin | admin123 |
| 演示会员 | demo | demo123 |

> ⚠️ **上线后请立即修改管理员密码！**

---

## 第四步：后续更新代码

如果你以后修改了代码，想更新到线上：

```bash
# 进入项目文件夹
cd pickleball-club

# 添加修改
git add .

# 提交
git commit -m "更新了什么内容"

# 推送到 GitHub
git push origin main
```

Push 后，Railway 会自动检测代码变化并重新部署（大约 1-2 分钟）。

---

## 常见问题

**Q: 部署失败了怎么办？**
A: 在 Railway 项目页面点击 "View Logs" 查看错误日志。常见问题：
   - `Cannot find module 'express'` → 确保 `server/package.json` 在仓库里
   - `EADDRINUSE` → 端口被占用，重启项目即可
   - 数据库报错 → 删除 `server/data.db` 重新部署

**Q: 免费套餐够用吗？**
A: Railway 免费套餐提供：
   - 每月 5GB 流量（小型网站完全够用）
   - 512MB 内存（本项目只需要 ~100MB）
   - 1GB 存储空间
   - 项目 30 天不活跃会自动休眠（再次访问时自动唤醒，约 10 秒）

**Q: 自定义域名怎么做？**
A: Railway 项目 Settings → Domains → Add Custom Domain，输入你的域名（如 `www.yoursite.com`），然后在域名服务商添加 CNAME 记录指向 Railway 提供的地址。

**Q: 图片上传功能在 Railway 能用吗？**
A: 能用，但上传的文件只保存在当前实例中。如果 Railway 重启或重新部署，上传的文件会丢失。生产环境建议把图片上传到云存储（如 Cloudinary、AWS S3）。

---

## 需要帮助？

如果以上步骤有任何不清楚的地方，随时问我！可以把报错截图或具体描述发给我。