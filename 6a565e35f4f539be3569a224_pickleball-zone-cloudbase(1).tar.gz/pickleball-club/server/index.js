const express = require('express');
const path = require('path');
const cors = require('cors');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));
app.use('/assets', express.static(path.join(__dirname, '..', 'assets')));

// 路由
app.use('/api/auth', require('./routes/auth'));
app.use('/api/members', require('./routes/members'));
app.use('/api/activities', require('./routes/activities'));
app.use('/api/rewards', require('./routes/rewards'));
app.use('/api/articles', require('./routes/articles'));
app.use('/api/admin', require('./routes/admin'));
app.use('/api/upload', require('./routes/upload'));

// 前端静态文件
app.use(express.static(path.join(__dirname, '..')));
app.get('/', (req, res) => res.sendFile(path.join(__dirname, '..', 'pickleball-club.html')));
app.get('/login', (req, res) => res.sendFile(path.join(__dirname, '..', 'login.html')));
app.get('/register', (req, res) => res.sendFile(path.join(__dirname, '..', 'register.html')));
app.get('/member', (req, res) => res.sendFile(path.join(__dirname, '..', 'member.html')));
app.get('/member/activities', (req, res) => res.sendFile(path.join(__dirname, '..', 'member-activities.html')));
app.get('/member/rewards', (req, res) => res.sendFile(path.join(__dirname, '..', 'member-rewards.html')));
app.get('/admin', (req, res) => res.sendFile(path.join(__dirname, '..', 'admin.html')));

// 全局错误处理 — 防止未捕获异常导致服务器崩溃
app.use('/api', (err, req, res, next) => {
  console.error('API Error:', err.message);
  res.status(500).json({ error: '服务器内部错误: ' + err.message });
});

app.listen(PORT, () => {
  console.log(`✓ Pickleball Zone 服务器已启动: http://localhost:${PORT}`);
});