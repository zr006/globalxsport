const Database = require('better-sqlite3');
const path = require('path');
const fs = require('fs');

const DB_PATH = path.join(__dirname, 'data.db');
const UPLOADS_DIR = path.join(__dirname, 'uploads');

if (!fs.existsSync(UPLOADS_DIR)) fs.mkdirSync(UPLOADS_DIR, { recursive: true });

const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

// ── 管理员表 ──
db.exec(`
  CREATE TABLE IF NOT EXISTS admins (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    created_at TEXT DEFAULT (datetime('now','localtime'))
  );
`);

// ── 会员表 ──
db.exec(`
  CREATE TABLE IF NOT EXISTS members (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    nickname TEXT NOT NULL,
    email TEXT UNIQUE,
    phone TEXT,
    avatar TEXT DEFAULT '',
    points INTEGER DEFAULT 0,
    total_points_earned INTEGER DEFAULT 0,
    created_at TEXT DEFAULT (datetime('now','localtime'))
  );
`);

// ── 积分记录表 ──
db.exec(`
  CREATE TABLE IF NOT EXISTS point_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    member_id INTEGER NOT NULL,
    change_amount INTEGER NOT NULL,
    reason TEXT NOT NULL,
    related_id INTEGER,
    related_type TEXT,
    created_at TEXT DEFAULT (datetime('now','localtime')),
    FOREIGN KEY (member_id) REFERENCES members(id)
  );
`);

// ── 活动表 ──
db.exec(`
  CREATE TABLE IF NOT EXISTS activities (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    description TEXT,
    category TEXT DEFAULT '匹克球',
    date TEXT NOT NULL,
    time TEXT,
    location TEXT,
    max_participants INTEGER DEFAULT 30,
    points_reward INTEGER DEFAULT 50,
    cover_image TEXT DEFAULT '',
    status TEXT DEFAULT 'open' CHECK(status IN ('open','full','closed','cancelled')),
    created_at TEXT DEFAULT (datetime('now','localtime')),
    updated_at TEXT DEFAULT (datetime('now','localtime'))
  );
`);

// ── 活动报名表 ──
db.exec(`
  CREATE TABLE IF NOT EXISTS registrations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    member_id INTEGER NOT NULL,
    activity_id INTEGER NOT NULL,
    status TEXT DEFAULT 'registered' CHECK(status IN ('registered','attended','cancelled','no_show','checked_in')),
    points_awarded INTEGER DEFAULT 0,
    registered_at TEXT DEFAULT (datetime('now','localtime')),
    UNIQUE(member_id, activity_id),
    FOREIGN KEY (member_id) REFERENCES members(id),
    FOREIGN KEY (activity_id) REFERENCES activities(id)
  );
`);

// ── 兑换礼品表 ──
db.exec(`
  CREATE TABLE IF NOT EXISTS rewards (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    description TEXT,
    points_required INTEGER NOT NULL,
    stock INTEGER DEFAULT 0,
    image TEXT DEFAULT '',
    is_active INTEGER DEFAULT 1,
    created_at TEXT DEFAULT (datetime('now','localtime'))
  );
`);

// ── 积分兑换记录 ──
db.exec(`
  CREATE TABLE IF NOT EXISTS redemptions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    member_id INTEGER NOT NULL,
    reward_id INTEGER NOT NULL,
    points_spent INTEGER NOT NULL,
    status TEXT DEFAULT 'pending' CHECK(status IN ('pending','fulfilled','cancelled')),
    created_at TEXT DEFAULT (datetime('now','localtime')),
    FOREIGN KEY (member_id) REFERENCES members(id),
    FOREIGN KEY (reward_id) REFERENCES rewards(id)
  );
`);

// ── 资讯/文章表 ──
db.exec(`
  CREATE TABLE IF NOT EXISTS articles (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    excerpt TEXT,
    content TEXT,
    category TEXT DEFAULT '匹克球',
    cover_image TEXT DEFAULT '',
    is_published INTEGER DEFAULT 0,
    views INTEGER DEFAULT 0,
    published_at TEXT,
    created_at TEXT DEFAULT (datetime('now','localtime')),
    updated_at TEXT DEFAULT (datetime('now','localtime'))
  );
`);

// ── 媒体库表 ──
db.exec(`
  CREATE TABLE IF NOT EXISTS media (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    filename TEXT NOT NULL,
    original_name TEXT,
    mime_type TEXT,
    size INTEGER,
    url TEXT NOT NULL,
    uploaded_by TEXT,
    created_at TEXT DEFAULT (datetime('now','localtime'))
  );
`);

// ── 种子数据 ──
const bcrypt = require('bcryptjs');

// 管理员
const adminExists = db.prepare('SELECT id FROM admins WHERE username = ?').get('admin');
if (!adminExists) {
  const hash = bcrypt.hashSync('admin123', 10);
  db.prepare('INSERT INTO admins (username, password_hash) VALUES (?, ?)').run('admin', hash);
}

// 示例会员
const memberExists = db.prepare('SELECT id FROM members WHERE username = ?').get('demo');
if (!memberExists) {
  const hash = bcrypt.hashSync('demo123', 10);
  const info = db.prepare('INSERT INTO members (username, password_hash, nickname, email, phone, points) VALUES (?, ?, ?, ?, ?, ?)').run(
    'demo', hash, '张三', 'demo@pzclub.com', '13800138000', 1250
  );
  const mid = info.lastInsertRowid;
  db.prepare('INSERT INTO point_logs (member_id, change_amount, reason, related_type) VALUES (?, ?, ?, ?)').run(mid, 200, '注册奖励', 'system');
  db.prepare('INSERT INTO point_logs (member_id, change_amount, reason, related_type) VALUES (?, ?, ?, ?)').run(mid, 350, '参加活动签到', 'activity');
  db.prepare('INSERT INTO point_logs (member_id, change_amount, reason, related_type) VALUES (?, ?, ?, ?)').run(mid, 500, '赛事志愿者奖励', 'event');
  db.prepare('INSERT INTO point_logs (member_id, change_amount, reason, related_type) VALUES (?, ?, ?, ?)').run(mid, 200, '每日签到奖励', 'system');
}

// 第二个示例会员
const member2Exists = db.prepare('SELECT id FROM members WHERE username = ?').get('player2');
if (!member2Exists) {
  const hash = bcrypt.hashSync('player123', 10);
  db.prepare('INSERT INTO members (username, password_hash, nickname, email, phone, points) VALUES (?, ?, ?, ?, ?, ?)').run(
    'player2', hash, '李四', 'lisi@pzclub.com', '13900139000', 800
  );
}

// 示例活动
const actCount = db.prepare('SELECT COUNT(*) as c FROM activities').get();
if (actCount.c === 0) {
  const now = new Date();
  const fmt = (d) => d.toISOString().split('T')[0];
  const addDays = (n) => { const d = new Date(now); d.setDate(d.getDate() + n); return fmt(d); };

  const acts = [
    ['PPA Asia 东京公开赛观赛派对', '一起观看PPA Asia东京公开赛的精彩直播！现场大屏幕转播，专业解说，还有互动抽奖环节。', '赛事活动', addDays(3), '14:00-18:00', '俱乐部大堂 · 观影区', 50, 100],
    ['周末匹克球公开赛（第32期）', '俱乐部每周常规公开赛，分为初级组和进阶组，双打淘汰赛制。', '匹克球', addDays(5), '09:00-17:00', 'A区 1-4号场地', 64, 80],
    ['Paddletek 球拍试打日', 'Paddletek 全新碳纤维球拍免费试打！Bantam系列、Tempest系列、Helios系列全线产品体验。', '装备体验', addDays(7), '10:00-16:00', 'B区 体验区', 30, 50],
    ['板式网球入门体验课', '零基础友好！专业教练带你2小时掌握板式网球基本规则和击球技巧，装备全包。', '板式网球', addDays(4), '15:00-17:00', 'C区 板式网球馆', 20, 60],
    ['MLP 赛季观赛之夜', 'Major League Pickleball 2026赛季季后赛观赛活动，Dallas Flash vs NY Pickleball Club！', '赛事活动', addDays(10), '19:00-22:00', '俱乐部大堂 · 观影区', 40, 80],
    ['匹克球进阶训练营（12期）', '由前全国冠军李明远主理，为期两天的集中训练营，涵盖发球、网前技术、战术体系。', '训练课程', addDays(14), '09:00-17:00', 'A区 全部场地', 24, 150],
  ];
  const insertAct = db.prepare('INSERT INTO activities (title, description, category, date, time, location, max_participants, points_reward, cover_image) VALUES (?,?,?,?,?,?,?,?,?)');
  for (const a of acts) {
    insertAct.run(...a, 'club_activity_1280x720.jpg');
  }
}

// 示例礼品
const rewCount = db.prepare('SELECT COUNT(*) as c FROM rewards').get();
if (rewCount.c === 0) {
  const rews = [
    ['Paddletek 球拍折扣券', 'Paddletek Bantam 系列球拍9折优惠券', 300, 50, ''],
    ['俱乐部场地免费券', '任意场地2小时免费使用权', 200, 100, ''],
    ['限量版运动毛巾', 'Pickleball Zone 俱乐部限定运动毛巾', 150, 200, ''],
    ['训练课程抵用券', '任意进阶训练课程1次免费', 400, 30, ''],
    ['品牌运动水壶', 'PZ Club 联名保温运动水壶', 250, 80, ''],
    ['赛事报名优先卡', '任一赛事优先报名权 + 免报名费', 500, 20, ''],
  ];
  const insertRew = db.prepare('INSERT INTO rewards (name, description, points_required, stock, image) VALUES (?,?,?,?,?)');
  for (const r of rews) insertRew.run(...r);
}

// 示例文章
const artCount = db.prepare('SELECT COUNT(*) as c FROM articles').get();
if (artCount.c === 0) {
  const articles = [
    ['PPA Asia 东京公开赛精彩回顾', 'PPA ASIA 500 Sansan TOKYO OPEN 2026于7月1-4日在东京立川 Arena Tachikawa 成功举办。11片全空调场地，1000名选手参赛，创亚洲匹克球赛事规模新高。', '赛事', 'ppa_tokyo_event_1280x720.jpg', 1, 5620],
    ['Paddletek 2026年中球拍横评', '从Bantam TKO-CX到Tempest Wave Pro，我们实测了Paddletek旗下五款热门球拍。碳纤维vs玻纤、长手柄vs标准，不同打法该如何选择？', '装备', 'paddletek_equip_1280x720.jpg', 1, 3200],
    ['Christian Alshon：从NCAA到MLP历史第一人', '仅用三年时间从大学网球冠军成长为职业匹克球顶级选手，Christian Alshon用力量和花式击球征服了PPA巡回赛。更成为MLP历史上唯一在Challenger和Premier双级别夺冠的球员。', '人物', 'player_alshon_800x600.jpg', 1, 4800],
    ['Riley Newman：网前大师的进击之路', '身高188cm的Riley Newman以其出色的网前控制力和稳定性闻名PPA巡回赛。作为Paddletek战队核心成员，他在男双和混双项目中持续保持Top 20排名。', '人物', 'player_newman_800x600.jpg', 1, 2100],
    ['Scott Moore：三冠王"野兽"的传奇生涯', '6次Triple Crown得主、20枚USAPA全国锦标赛金牌、12枚US Open金牌——Scott Moore是当之无愧的老年组传奇。30多年网球经历造就了他侵略性极强的"野兽"打法。', '人物', 'player_moore_800x600.jpg', 1, 3800],
    ['Hurricane Tyra Black：飓风来袭', '2024年MLP Premier冠军、PPA女双排名Top 3、混双Top 4——年仅25岁的Tyra Black正以标志性flick shot席卷职业匹克球赛场。', '人物', 'player_tyra_800x600.jpg', 1, 4500],
    ['MLP 2026赛季全面升级：统一规则、20队争霸', 'Major League Pickleball 2026赛季取消Premier/Challenger分级，20支队伍统一参赛。PPA Tour与MLP首次采用统一规则手册，总奖金超300万美元。', '赛事', 'club_activity_1280x720.jpg', 1, 2900],
    ['零基础到赛场：匹克球发球技巧完全指南', '专业教练解析三种主流发球动作——硬发球、柔和发球和带旋转发球。配合分步教学和常见错误纠正，助你快速掌握得分利器。', '教学', 'club_activity_1280x720.jpg', 1, 1800],
    ['2026 全国匹克球锦标赛赛程公布', '中国匹克球运动协会公布2026年全国锦标赛完整赛程，8月15-20日在深圳湾体育中心举办，首次增设混合双打项目，预计超800名选手参赛。', '赛事', 'ppa_tokyo_event_1280x720.jpg', 1, 6200],
  ];
  const insertArt = db.prepare("INSERT INTO articles (title, excerpt, content, category, cover_image, is_published, views, published_at) VALUES (?,?,?,?,?,?,?,datetime('now','localtime'))");
  for (const a of articles) insertArt.run(a[0], a[1], a[1] + '\n\n（完整文章内容在此处展示...）', a[2], a[3], a[4], a[5]);
}

console.log('✓ 数据库初始化完成');
console.log('  管理员账号: admin / admin123');
console.log('  演示会员账号: demo / demo123');
db.close();