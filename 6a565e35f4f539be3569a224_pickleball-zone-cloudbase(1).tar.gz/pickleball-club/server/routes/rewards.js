const express = require('express');
const { getDb, requireMember } = require('../middleware/auth');
const router = express.Router();

// 获取礼品列表
router.get('/', (req, res) => {
  try {
    const db = getDb();
    const rewards = db.prepare('SELECT * FROM rewards WHERE is_active = 1 ORDER BY points_required ASC').all();
    db.close();
    res.json(rewards);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// 兑换礼品
router.post('/:id/redeem', requireMember, (req, res) => {
  try {
    const db = getDb();
    const reward = db.prepare('SELECT * FROM rewards WHERE id = ? AND is_active = 1').get(req.params.id);
    if (!reward) { db.close(); return res.status(404).json({ error: '礼品不存在' }); }
    if (reward.stock <= 0) { db.close(); return res.status(400).json({ error: '礼品已售罄' }); }
    const member = db.prepare('SELECT points FROM members WHERE id = ?').get(req.memberId);
    if (member.points < reward.points_required) { db.close(); return res.status(400).json({ error: '积分不足，需要 ' + reward.points_required + ' 积分' }); }
    // 扣积分
    db.prepare('UPDATE members SET points = points - ? WHERE id = ?').run(reward.points_required, req.memberId);
    // 记录积分变动
    db.prepare('INSERT INTO point_logs (member_id, change_amount, reason, related_id, related_type) VALUES (?, ?, ?, ?, ?)').run(
      req.memberId, -reward.points_required, '兑换: ' + reward.name, reward.id, 'reward'
    );
    // 扣库存
    db.prepare('UPDATE rewards SET stock = stock - 1 WHERE id = ?').run(reward.id);
    // 创建兑换记录
    db.prepare('INSERT INTO redemptions (member_id, reward_id, points_spent, status) VALUES (?, ?, ?, ?)').run(req.memberId, reward.id, reward.points_required, 'pending');
    const updated = db.prepare('SELECT points FROM members WHERE id = ?').get(req.memberId);
    db.close();
    res.json({ message: '兑换成功！已扣除 ' + reward.points_required + ' 积分', points: updated.points });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// 获取我的兑换记录
router.get('/my-redemptions', requireMember, (req, res) => {
  try {
    const db = getDb();
    const redemptions = db.prepare(`
      SELECT r.*, rw.name as reward_name, rw.image as reward_image
      FROM redemptions r
      JOIN rewards rw ON r.reward_id = rw.id
      WHERE r.member_id = ?
      ORDER BY r.created_at DESC
    `).all(req.memberId);
    db.close();
    res.json(redemptions);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

module.exports = router;