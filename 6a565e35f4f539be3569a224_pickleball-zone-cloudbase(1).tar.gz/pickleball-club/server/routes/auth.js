const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { getDb, JWT_SECRET } = require('../middleware/auth');
const router = express.Router();

// 会员注册
router.post('/register', (req, res) => {
  try {
    const { username, password, nickname, email, phone } = req.body;
    if (!username || !password || !nickname) {
      return res.status(400).json({ error: '用户名、密码和昵称为必填项' });
    }
    if (username.length < 3 || password.length < 6) {
      return res.status(400).json({ error: '用户名至少3位，密码至少6位' });
    }
    const db = getDb();
    const exists = db.prepare('SELECT id FROM members WHERE username = ? OR email = ?').get(username, email || '');
    if (exists) {
      db.close();
      return res.status(409).json({ error: '用户名或邮箱已存在' });
    }
    const hash = bcrypt.hashSync(password, 10);
    const info = db.prepare('INSERT INTO members (username, password_hash, nickname, email, phone, points) VALUES (?, ?, ?, ?, ?, 0)').run(username, hash, nickname, email || '', phone || '');
    const memberId = info.lastInsertRowid;
    // 注册奖励积分
    db.prepare('UPDATE members SET points = points + 200, total_points_earned = total_points_earned + 200 WHERE id = ?').run(memberId);
    db.prepare('INSERT INTO point_logs (member_id, change_amount, reason, related_type) VALUES (?, ?, ?, ?)').run(memberId, 200, '注册奖励', 'system');
    const token = jwt.sign({ id: memberId, role: 'member' }, JWT_SECRET, { expiresIn: '7d' });
    const member = db.prepare('SELECT id, username, nickname, email, phone, points, total_points_earned, avatar, created_at FROM members WHERE id = ?').get(memberId);
    db.close();
    res.status(201).json({ token, member });
  } catch (e) {
    res.status(500).json({ error: '注册失败: ' + e.message });
  }
});

// 会员登录
router.post('/login', (req, res) => {
  try {
    const { username, password } = req.body;
    if (!username || !password) {
      return res.status(400).json({ error: '请输入用户名和密码' });
    }
    const db = getDb();
    const member = db.prepare('SELECT * FROM members WHERE username = ?').get(username);
    if (!member || !bcrypt.compareSync(password, member.password_hash)) {
      db.close();
      return res.status(401).json({ error: '用户名或密码错误' });
    }
    const token = jwt.sign({ id: member.id, role: 'member' }, JWT_SECRET, { expiresIn: '7d' });
    const { password_hash, ...profile } = member;
    db.close();
    res.json({ token, member: profile });
  } catch (e) {
    res.status(500).json({ error: '登录失败: ' + e.message });
  }
});

// 管理员登录
router.post('/admin-login', (req, res) => {
  try {
    const { username, password } = req.body;
    const db = getDb();
    const admin = db.prepare('SELECT * FROM admins WHERE username = ?').get(username);
    if (!admin || !bcrypt.compareSync(password, admin.password_hash)) {
      db.close();
      return res.status(401).json({ error: '管理员账号或密码错误' });
    }
    const token = jwt.sign({ id: admin.id, role: 'admin' }, JWT_SECRET, { expiresIn: '24h' });
    db.close();
    res.json({ token, admin: { id: admin.id, username: admin.username } });
  } catch (e) {
    res.status(500).json({ error: '登录失败: ' + e.message });
  }
});

// 获取当前用户信息
router.get('/me', (req, res) => {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) return res.status(200).json(null);
  try {
    const decoded = jwt.verify(authHeader.split(' ')[1], JWT_SECRET);
    const db = getDb();
    if (decoded.role === 'member') {
      const member = db.prepare('SELECT id, username, nickname, email, phone, points, total_points_earned, avatar, created_at FROM members WHERE id = ?').get(decoded.id);
      db.close();
      return res.json({ role: 'member', user: member });
    } else if (decoded.role === 'admin') {
      const admin = db.prepare('SELECT id, username FROM admins WHERE id = ?').get(decoded.id);
      db.close();
      return res.json({ role: 'admin', user: admin });
    }
    db.close();
    res.json(null);
  } catch (e) { res.json(null); }
});

module.exports = router;