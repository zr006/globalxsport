const express = require('express');
const multer = require('multer');
const path = require('path');
const { getDb, requireAdmin } = require('../middleware/auth');
const router = express.Router();

const upload = multer({ dest: path.join(__dirname, '..', 'uploads'), limits: { fileSize: 10 * 1024 * 1024 } });

// 统计概览
router.get('/dashboard', requireAdmin, (req, res) => {
  try {
    const db = getDb();
    const memberCount = db.prepare('SELECT COUNT(*) as c FROM members').get().c;
    const activityCount = db.prepare('SELECT COUNT(*) as c FROM activities').get().c;
    const articleCount = db.prepare('SELECT COUNT(*) as c FROM articles WHERE is_published = 1').get().c;
    const regToday = db.prepare("SELECT COUNT(*) as c FROM registrations WHERE date(registered_at) = date('now','localtime')").get().c;
    db.close();
    res.json({ memberCount, activityCount, articleCount, regToday });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ── 文章管理 ──
router.get('/articles', requireAdmin, (req, res) => {
  const db = getDb();
  const articles = db.prepare('SELECT * FROM articles ORDER BY created_at DESC').all();
  db.close(); res.json(articles);
});
router.post('/articles', requireAdmin, (req, res) => {
  try {
    const { title, excerpt, content, category, cover_image, is_published } = req.body;
    const db = getDb();
    if (is_published) {
      db.prepare("INSERT INTO articles (title, excerpt, content, category, cover_image, is_published, published_at) VALUES (?,?,?,?,?,?,datetime('now','localtime'))").run(
        title, excerpt || '', content || '', category || '匹克球', cover_image || '', 1
      );
    } else {
      db.prepare('INSERT INTO articles (title, excerpt, content, category, cover_image, is_published) VALUES (?,?,?,?,?,?)').run(
        title, excerpt || '', content || '', category || '匹克球', cover_image || '', 0
      );
    }
    db.close(); res.json({ message: '文章已创建' });
  } catch (e) { res.status(500).json({ error: e.message }); }
});
router.put('/articles/:id', requireAdmin, (req, res) => {
  try {
    const { title, excerpt, content, category, cover_image, is_published } = req.body;
    const db = getDb();
    const article = db.prepare('SELECT published_at FROM articles WHERE id = ?').get(req.params.id);
    if (is_published && !article.published_at) {
      db.prepare("UPDATE articles SET title=?, excerpt=?, content=?, category=?, cover_image=?, is_published=?, published_at=datetime('now','localtime') WHERE id=?").run(title, excerpt, content, category, cover_image, is_published ? 1 : 0, req.params.id);
    } else {
      db.prepare('UPDATE articles SET title=?, excerpt=?, content=?, category=?, cover_image=?, is_published=? WHERE id=?').run(title, excerpt, content, category, cover_image, is_published ? 1 : 0, req.params.id);
    }
    db.close(); res.json({ message: '文章已更新' });
  } catch (e) { res.status(500).json({ error: e.message }); }
});
router.delete('/articles/:id', requireAdmin, (req, res) => {
  const db = getDb();
  db.prepare('DELETE FROM articles WHERE id = ?').run(req.params.id);
  db.close(); res.json({ message: '文章已删除' });
});

// ── 活动管理 ──
router.get('/activities', requireAdmin, (req, res) => {
  const db = getDb();
  const activities = db.prepare(`SELECT a.*, (SELECT COUNT(*) FROM registrations WHERE activity_id = a.id AND status = 'registered') as participant_count FROM activities a ORDER BY a.date DESC`).all();
  db.close(); res.json(activities);
});
router.post('/activities', requireAdmin, (req, res) => {
  const { title, description, category, date, time, location, max_participants, points_reward, cover_image, status } = req.body;
  const db = getDb();
  db.prepare('INSERT INTO activities (title, description, category, date, time, location, max_participants, points_reward, cover_image, status) VALUES (?,?,?,?,?,?,?,?,?,?)').run(
    title, description || '', category || '匹克球', date, time || '', location || '', max_participants || 30, points_reward || 50, cover_image || '', status || 'open'
  );
  db.close(); res.json({ message: '活动已创建' });
});
router.put('/activities/:id', requireAdmin, (req, res) => {
  try {
    const { title, description, category, date, time, location, max_participants, points_reward, cover_image, status } = req.body;
    const db = getDb();
    db.prepare("UPDATE activities SET title=?, description=?, category=?, date=?, time=?, location=?, max_participants=?, points_reward=?, cover_image=?, status=?, updated_at=datetime('now','localtime') WHERE id=?").run(
      title, description, category, date, time, location, max_participants, points_reward, cover_image, status, req.params.id
    );
    db.close(); res.json({ message: '活动已更新' });
  } catch (e) { res.status(500).json({ error: e.message }); }
});
router.delete('/activities/:id', requireAdmin, (req, res) => {
  const db = getDb();
  db.prepare('DELETE FROM registrations WHERE activity_id = ?').run(req.params.id);
  db.prepare('DELETE FROM activities WHERE id = ?').run(req.params.id);
  db.close(); res.json({ message: '活动已删除' });
});

// ── 活动签到 & 积分 ──
router.post('/activities/:id/checkin/:memberId', requireAdmin, (req, res) => {
  try {
    const db = getDb();
    const reg = db.prepare("SELECT * FROM registrations WHERE activity_id = ? AND member_id = ? AND status = 'registered'").get(req.params.id, req.params.memberId);
    if (!reg) { db.close(); return res.status(400).json({ error: '未找到有效报名记录' }); }
    db.prepare("UPDATE registrations SET status = 'attended', points_awarded = (SELECT points_reward FROM activities WHERE id = ?) WHERE id = ?").run(req.params.id, reg.id);
    const reward = db.prepare('SELECT points_reward FROM activities WHERE id = ?').get(req.params.id).points_reward;
    db.prepare('UPDATE members SET points = points + ?, total_points_earned = total_points_earned + ? WHERE id = ?').run(reward, reward, req.params.memberId);
    db.prepare('INSERT INTO point_logs (member_id, change_amount, reason, related_id, related_type) VALUES (?, ?, ?, ?, ?)').run(req.params.memberId, reward, '活动签到: ' + (db.prepare('SELECT title FROM activities WHERE id = ?').get(req.params.id).title), req.params.id, 'activity');
    db.close(); res.json({ message: '签到成功，+' + reward + ' 积分' });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// 获取活动报名列表
router.get('/activities/:id/registrations', requireAdmin, (req, res) => {
  const db = getDb();
  const regs = db.prepare(`SELECT r.*, m.nickname, m.username, m.phone FROM registrations r JOIN members m ON r.member_id = m.id WHERE r.activity_id = ? ORDER BY r.registered_at`).all(req.params.id);
  db.close(); res.json(regs);
});

// ── 会员管理 ──
router.get('/members', requireAdmin, (req, res) => {
  const db = getDb();
  const members = db.prepare('SELECT id, username, nickname, email, phone, points, total_points_earned, created_at FROM members ORDER BY created_at DESC').all();
  db.close(); res.json(members);
});
router.put('/members/:id/points', requireAdmin, (req, res) => {
  const { change, reason } = req.body;
  const db = getDb();
  db.prepare('UPDATE members SET points = points + ?, total_points_earned = total_points_earned + CASE WHEN ? > 0 THEN ? ELSE 0 END WHERE id = ?').run(change, change, change, req.params.id);
  if (change > 0) {
    db.prepare('INSERT INTO point_logs (member_id, change_amount, reason, related_type) VALUES (?, ?, ?, ?)').run(req.params.id, change, reason || '管理员调整', 'admin');
  }
  const member = db.prepare('SELECT points FROM members WHERE id = ?').get(req.params.id);
  db.close(); res.json({ message: '积分已调整', points: member.points });
});

// ── 礼品管理 ──
router.get('/rewards', requireAdmin, (req, res) => {
  const db = getDb();
  const rewards = db.prepare('SELECT * FROM rewards ORDER BY points_required ASC').all();
  db.close(); res.json(rewards);
});
router.post('/rewards', requireAdmin, (req, res) => {
  const { name, description, points_required, stock, image, is_active } = req.body;
  const db = getDb();
  db.prepare('INSERT INTO rewards (name, description, points_required, stock, image, is_active) VALUES (?,?,?,?,?,?)').run(name, description || '', points_required, stock || 0, image || '', is_active !== false ? 1 : 0);
  db.close(); res.json({ message: '礼品已添加' });
});
router.put('/rewards/:id', requireAdmin, (req, res) => {
  const { name, description, points_required, stock, image, is_active } = req.body;
  const db = getDb();
  db.prepare('UPDATE rewards SET name=?, description=?, points_required=?, stock=?, image=?, is_active=? WHERE id=?').run(name, description, points_required, stock, image, is_active !== false ? 1 : 0, req.params.id);
  db.close(); res.json({ message: '礼品已更新' });
});
router.delete('/rewards/:id', requireAdmin, (req, res) => {
  const db = getDb();
  db.prepare('DELETE FROM rewards WHERE id = ?').run(req.params.id);
  db.close(); res.json({ message: '礼品已删除' });
});

// ── 兑换管理 ──
router.get('/redemptions', requireAdmin, (req, res) => {
  const db = getDb();
  const redemptions = db.prepare(`SELECT r.*, m.nickname as member_name, rw.name as reward_name FROM redemptions r JOIN members m ON r.member_id = m.id JOIN rewards rw ON r.reward_id = rw.id ORDER BY r.created_at DESC`).all();
  db.close(); res.json(redemptions);
});
router.put('/redemptions/:id/status', requireAdmin, (req, res) => {
  const { status } = req.body;
  const db = getDb();
  db.prepare('UPDATE redemptions SET status = ? WHERE id = ?').run(status, req.params.id);
  db.close(); res.json({ message: '兑换状态已更新' });
});

module.exports = router;