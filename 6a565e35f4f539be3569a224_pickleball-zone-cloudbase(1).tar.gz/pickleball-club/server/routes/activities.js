const express = require('express');
const { getDb, requireMember, optionalAuth } = require('../middleware/auth');
const router = express.Router();

// 获取活动列表（公开）
router.get('/', optionalAuth, (req, res) => {
  try {
    const { category, status } = req.query;
    let sql = 'SELECT a.*, (SELECT COUNT(*) FROM registrations WHERE activity_id = a.id AND status != ?) as participant_count FROM activities a WHERE 1=1';
    const params = ['cancelled'];
    if (category) { sql += ' AND a.category = ?'; params.push(category); }
    if (status) { sql += ' AND a.status = ?'; params.push(status); }
    sql += ' ORDER BY a.date ASC';
    const db = getDb();
    let activities = db.prepare(sql).all(...params);
    // 标记当前用户是否已报名
    if (req.userId && req.userRole === 'member') {
      const regs = db.prepare('SELECT activity_id FROM registrations WHERE member_id = ? AND status = ?').all(req.userId, 'registered');
      const regSet = new Set(regs.map(r => r.activity_id));
      activities = activities.map(a => ({ ...a, is_registered: regSet.has(a.id) }));
    }
    db.close();
    res.json(activities);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// 获取单个活动
router.get('/:id', (req, res) => {
  try {
    const db = getDb();
    const activity = db.prepare('SELECT * FROM activities WHERE id = ?').get(req.params.id);
    if (!activity) { db.close(); return res.status(404).json({ error: '活动不存在' }); }
    activity.participant_count = db.prepare('SELECT COUNT(*) as c FROM registrations WHERE activity_id = ? AND status != ?').get(req.params.id, 'cancelled').c;
    db.close();
    res.json(activity);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// 报名活动
router.post('/:id/register', requireMember, (req, res) => {
  try {
    const db = getDb();
    const activity = db.prepare('SELECT * FROM activities WHERE id = ?').get(req.params.id);
    if (!activity) { db.close(); return res.status(404).json({ error: '活动不存在' }); }
    if (activity.status !== 'open') { db.close(); return res.status(400).json({ error: '活动暂不接受报名' }); }
    const count = db.prepare('SELECT COUNT(*) as c FROM registrations WHERE activity_id = ? AND status = ?').get(req.params.id, 'registered').c;
    if (count >= activity.max_participants) {
      db.prepare('UPDATE activities SET status = ? WHERE id = ?').run('full', req.params.id);
      db.close(); return res.status(400).json({ error: '活动名额已满' });
    }
    const existing = db.prepare('SELECT id FROM registrations WHERE member_id = ? AND activity_id = ?').get(req.memberId, req.params.id);
    if (existing) { db.close(); return res.status(400).json({ error: '已报名此活动' }); }
    db.prepare('INSERT INTO registrations (member_id, activity_id) VALUES (?, ?)').run(req.memberId, req.params.id);
    const newCount = db.prepare('SELECT COUNT(*) as c FROM registrations WHERE activity_id = ? AND status = ?').get(req.params.id, 'registered').c;
    if (newCount >= activity.max_participants) {
      db.prepare('UPDATE activities SET status = ? WHERE id = ?').run('full', req.params.id);
    }
    db.close();
    res.json({ message: '报名成功！活动当天签到可获取 ' + activity.points_reward + ' 积分' });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// 取消报名
router.post('/:id/cancel', requireMember, (req, res) => {
  try {
    const db = getDb();
    const reg = db.prepare('SELECT * FROM registrations WHERE member_id = ? AND activity_id = ?').get(req.memberId, req.params.id);
    if (!reg || reg.status === 'cancelled') { db.close(); return res.status(400).json({ error: '未找到有效报名记录' }); }
    db.prepare('UPDATE registrations SET status = ? WHERE id = ?').run('cancelled', reg.id);
    db.prepare('UPDATE activities SET status = ? WHERE id = ? AND status = ?').run('open', req.params.id, 'full');
    db.close();
    res.json({ message: '已取消报名' });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// 活动签到
router.post('/:id/checkin', requireMember, (req, res) => {
  try {
    const db = getDb();
    const activity = db.prepare('SELECT * FROM activities WHERE id = ?').get(req.params.id);
    if (!activity) { db.close(); return res.status(404).json({ error: '活动不存在' }); }
    const reg = db.prepare('SELECT * FROM registrations WHERE member_id = ? AND activity_id = ? AND status = ?').get(req.memberId, req.params.id, 'registered');
    if (!reg) { db.close(); return res.status(400).json({ error: '未找到有效报名记录' }); }
    if (reg.status === 'checked_in') { db.close(); return res.status(400).json({ error: '已签到' }); }
    db.prepare('UPDATE registrations SET status = ? WHERE id = ?').run('checked_in', reg.id);
    db.prepare('UPDATE members SET points = points + ? WHERE id = ?').run(activity.points_reward, req.memberId);
    db.close();
    res.json({ message: '签到成功，获得 ' + activity.points_reward + ' 积分' });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

module.exports = router;