const express = require('express');
const multer = require('multer');
const path = require('path');
const { getDb, requireAdmin } = require('../middleware/auth');
const router = express.Router();

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, path.join(__dirname, '..', 'uploads')),
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname);
    cb(null, Date.now() + '-' + Math.random().toString(36).substr(2, 8) + ext);
  }
});
const upload = multer({
  storage,
  limits: { fileSize: 10 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    const allowed = /jpeg|jpg|png|gif|webp|svg/;
    const ext = allowed.test(path.extname(file.originalname).toLowerCase());
    const mime = allowed.test(file.mimetype.split('/')[1]);
    cb(null, ext || mime);
  }
});

// 上传图片
router.post('/', requireAdmin, upload.single('file'), (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ error: '请选择文件' });
    const url = '/uploads/' + req.file.filename;
    const db = getDb();
    db.prepare('INSERT INTO media (filename, original_name, mime_type, size, url, uploaded_by) VALUES (?,?,?,?,?,?)').run(
      req.file.filename, req.file.originalname, req.file.mimetype, req.file.size, url, 'admin'
    );
    const record = db.prepare('SELECT * FROM media WHERE filename = ?').get(req.file.filename);
    db.close();
    res.json({ url, id: record.id });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// 获取媒体列表
router.get('/', requireAdmin, (req, res) => {
  const db = getDb();
  const media = db.prepare('SELECT * FROM media ORDER BY created_at DESC LIMIT 50').all();
  db.close(); res.json(media);
});

// 删除媒体
router.delete('/:id', requireAdmin, (req, res) => {
  const db = getDb();
  const file = db.prepare('SELECT * FROM media WHERE id = ?').get(req.params.id);
  if (file) {
    const fs = require('fs');
    const filePath = path.join(__dirname, '..', 'uploads', file.filename);
    if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
    db.prepare('DELETE FROM media WHERE id = ?').run(req.params.id);
  }
  db.close(); res.json({ message: '已删除' });
});

module.exports = router;