const express = require('express');
const { getDb, optionalAuth } = require('../middleware/auth');
const router = express.Router();

// 获取已发布文章
router.get('/', optionalAuth, (req, res) => {
  try {
    const { category, limit = 20, offset = 0 } = req.query;
    let sql = 'SELECT id, title, excerpt, category, cover_image, views, published_at FROM articles WHERE is_published = 1';
    const params = [];
    if (category) { sql += ' AND category = ?'; params.push(category); }
    sql += ' ORDER BY published_at DESC LIMIT ? OFFSET ?';
    params.push(Number(limit), Number(offset));
    const db = getDb();
    const articles = db.prepare(sql).all(...params);
    const total = db.prepare('SELECT COUNT(*) as c FROM articles WHERE is_published = 1').get().c;
    db.close();
    res.json({ articles, total });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// 获取单篇文章
router.get('/:id', (req, res) => {
  try {
    const db = getDb();
    const article = db.prepare('SELECT * FROM articles WHERE id = ? AND is_published = 1').get(req.params.id);
    if (!article) { db.close(); return res.status(404).json({ error: '文章不存在' }); }
    db.prepare('UPDATE articles SET views = views + 1 WHERE id = ?').run(req.params.id);
    article.views += 1;
    db.close();
    res.json(article);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

module.exports = router;