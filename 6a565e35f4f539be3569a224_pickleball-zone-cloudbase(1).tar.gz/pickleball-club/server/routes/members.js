const express = require('express');
const { getDb, requireMember } = require('../middleware/auth');
const router = express.Router();

// 获取会员资料
router.get('/profile', requireMember, (req, res) => {
  try {
    const db = getDb();
    const member = db.prepare('SELECT id, username, nickname, email, phone, points, total_points_earned, avatar, created_at FROM members WHERE id = ?').get(req.memberId);
    if (!member) { db.close(); return res.status(404).json({ error: '会员不存在' }); }
    db.close();
    res.json(member);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// 更新会员资料
router.put('/profile', requireMember, (req, res) => {
  try {
    const { nickname, email, phone } = req.body;
    const db = getDb();
    db.prepare('UPDATE members SET nickname = COALESCE(?, nickname), email = COALESCE(?, email), phone = COALESCE(?, phone) WHERE id = ?').run(nickname || null, email || null, phone || null, req.memberId);
    const member = db.prepare('SELECT id, username, nickname, email, phone, points, total_points_earned, avatar, created_at FROM members WHERE id = ?').get(req.memberId);
    db.close();
    res.json(member);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// 获取我的活动记录
router.get('/my-activities', requireMember, (req, res) => {
  try {
    const db = getDb();
    const activities = db.prepare(`
      SELECT a.*, r.status as reg_status, r.registered_at, r.points_awarded
      FROM registrations r
      JOIN activities a ON r.activity_id = a.id
      WHERE r.member_id = ?
      ORDER BY r.registered_at DESC
    `).all(req.memberId);
    db.close();
    res.json(activities);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// 获取积分记录
router.get('/points', requireMember, (req, res) => {
  try {
    const db = getDb();
    const logs = db.prepare('SELECT * FROM point_logs WHERE member_id = ? ORDER BY created_at DESC LIMIT 50').all(req.memberId);
    const member = db.prepare('SELECT points, total_points_earned FROM members WHERE id = ?').get(req.memberId);
    db.close();
    res.json({ logs, current: member.points, total: member.total_points_earned });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// 每日签到
router.post('/check-in', requireMember, (req, res) => {
  try {
    const db = getDb();
    const today = new Date().toISOString().split('T')[0];
    const existing = db.prepare("SELECT id FROM point_logs WHERE member_id = ? AND reason = '每日签到' AND date(created_at) = date('now','localtime')").get(req.memberId);
    if (existing) { db.close(); return res.status(400).json({ error: '今日已签到' }); }
    db.prepare('UPDATE members SET points = points + 10, total_points_earned = total_points_earned + 10 WHERE id = ?').run(req.memberId);
    db.prepare("INSERT INTO point_logs (member_id, change_amount, reason, related_type) VALUES (?, 10, '每日签到', 'system')").run(req.memberId);
    const member = db.prepare('SELECT points FROM members WHERE id = ?').get(req.memberId);
    db.close();
    res.json({ points: member.points, earned: 10, message: '签到成功！+10积分' });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// 修改密码
router.put('/password', requireMember, (req, res) => {
  try {
    const bcrypt = require('bcryptjs');
    const { oldPassword, newPassword } = req.body;
    if (!oldPassword || !newPassword || newPassword.length < 6) {
      return res.status(400).json({ error: '新密码至少6位' });
    }
    const db = getDb();
    const member = db.prepare('SELECT password_hash FROM members WHERE id = ?').get(req.memberId);
    if (!bcrypt.compareSync(oldPassword, member.password_hash)) {
      db.close(); return res.status(401).json({ error: '原密码错误' });
    }
    db.prepare('UPDATE members SET password_hash = ? WHERE id = ?').run(bcrypt.hashSync(newPassword, 10), req.memberId);
    db.close();
    res.json({ message: '密码修改成功' });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

module.exports = router;