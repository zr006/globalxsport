# Pickleball Zone — Render 小白部署指南

> 本指南面向零基础用户，每一步都有详细说明。跟着做，10 分钟内你的网站就能上线。

---

## 你需要准备什么？

只需要两样东西，都是免费的：

1. **GitHub 账号** — 用来存放代码
   - 没有的话去 [github.com](https://github.com) 注册，用邮箱就行

2. **Render 账号** — 用来部署网站（免费云服务器）
   - 去 [render.com](https://render.com) 注册，可以直接用 GitHub 账号登录

---

## 第一步：把代码推送到 GitHub

### 1.1 创建 GitHub 仓库

1. 打开 [github.com](https://github.com)，登录你的账号
2. 点击页面右上角的 **"+"** 按钮，选择 **"New repository"**
3. 填写：
   - **Repository name**: `pickleball-zone`
   - **Public** / **Private**: 选 **Public**
   - **Initialize this repository with**: **什么都不勾选**（留空）
4. 点击绿色按钮 **"Create repository"**

### 1.2 上传代码到 GitHub

**方法一：用 Git 命令（推荐）**

打开电脑的「终端」或「命令提示符」，依次输入：

```bash
# 1. 解压 tar.gz 文件（如果还没解压）
# Mac:    tar -xzf pickleball-zone-railway.tar.gz
# Windows: 用 7-Zip 或 WinRAR 解压

# 2. 进入解压后的项目文件夹
cd /Users/你的用户名/Downloads/pickleball-club

# 3. 初始化 Git
git init

# 4. 添加所有文件
git add .

# 5. 提交
git commit -m "Initial commit"

# 6. 连接 GitHub（把 "你的用户名" 换成你的 GitHub 用户名）
git remote add origin https://github.com/你的用户名/pickleball-zone.git

# 7. 推送
git branch -M main
git push -u origin main
```

> **关于密码**：推送时会要求输入密码。这个密码不是你的 GitHub 登录密码，而是 **Personal Access Token**。
>
> 获取方法：
> 1. GitHub 页面 → 右上角头像 → **Settings**
> 2. 左侧最下面 → **Developer settings**
> 3. 左侧 → **Personal access tokens** → **Tokens (classic)**
> 4. 点 **Generate new token (classic)**
> 5. Note 随便填，Expiration 选 90 天
> 6. 勾选 **repo**（第一个选项），点 **Generate**
> 7. 复制那串字母数字（只显示一次！），用它作为密码

**方法二：直接网页上传（不用学 Git）**

1. 在 GitHub 仓库页面，点击 **"uploading an existing file"** 链接
2. 点击 **"choose your files"**，选择解压后的 `pickleball-club` 文件夹里的所有文件
   - ⚠️ 记得展开子文件夹，把 `_shared/fonts/`、`assets/`、`server/routes/`、`server/middleware/` 里的文件也选上
3. 底部写：`Initial commit`
4. 点 **"Commit changes"**

### 1.3 确认上传成功

回到 GitHub 仓库页面，应该能看到这些文件：
- `pickleball-club.html`（首页）
- `login.html`、`register.html`、`member.html` 等页面
- `render.yaml`（Render 配置文件 ← 关键！）
- `server/` 文件夹（后端代码）
- `assets/` 文件夹（图片）

---

## 第二步：在 Render 上部署

### 2.1 注册 / 登录 Render

1. 打开 [render.com](https://render.com)
2. 点击右上角 **"Get Started for Free"**
3. 选择 **"Continue with GitHub"**，用 GitHub 账号登录
4. 可能会要求你授权 Render 访问 GitHub 仓库，点 **"Authorize"**

### 2.2 创建 Web Service

1. 登录后，点击 **"New"** 按钮（页面左上角或 Dashboard 中间）
2. 选择 **"Web Service"**
3. 在 "Connect a repository" 下，找到你的 `pickleball-zone` 仓库
   - 如果看不到，点 **"Configure account"** 或 **"Connect more repositories"**，勾选你的仓库
4. 找到后，点击仓库右边的 **"Connect"** 按钮

### 2.3 填写部署配置

连接仓库后，进入配置页面。**大部分 Render 会自动识别，你只需要确认以下几项：**

| 设置项 | 应该填什么 | 说明 |
|--------|-----------|------|
| **Name** | `pickleball-zone` | 随便取，就是项目名字 |
| **Region** | `Singapore` 或 `Oregon` | 选离你近的节点（亚洲选 Singapore） |
| **Instance Type** | `Free` | **一定要选 Free！** |
| **Runtime** | `Node` | 自动识别，不用改 |
| **Build Command** | `cd server && npm install --production && node db.js` | 安装依赖 + 初始化数据库 |
| **Start Command** | `cd server && node index.js` | 启动服务器 |

> **如果 Render 自动检测到了 `render.yaml`**，以上配置会自动填好，你只需要：
> 1. 确认 **Instance Type** 是 **Free**
> 2. 点 **"Create Web Service"**

### 2.4 开始部署

1. 滚动到页面最底部，点击蓝色的 **"Create Web Service"** 按钮
2. 页面会跳转到部署日志页面，你会看到日志在滚动
3. 大概 **2-3 分钟**，看到以下信息就表示成功了：
   - `✓ Live — https://pickleball-zone-xxxx.onrender.com`
   - 旁边会出现一个 **"Open"** 绿色按钮

### 2.5 获取你的公开网址

部署成功后，你的网址就是页面顶部显示的那个链接，格式类似：

```
https://pickleball-zone-xxxx.onrender.com
```

点击就能在浏览器中打开，全世界都能访问！

---

## 第三步：验证网站

打开你的网址，测试以下页面：

| 页面 | 地址 | 操作 |
|------|------|------|
| 首页 | `/` | 查看球员、赛事内容是否正常 |
| 登录 | `/login` | 用 demo / demo123 登录 |
| 会员中心 | `/member` | 查看积分、签到 |
| 活动报名 | `/member/activities` | 报名/取消活动 |
| 积分兑换 | `/member/rewards` | 浏览/兑换礼品 |
| 管理后台 | `/admin` | 用 admin / admin123 登录 |

---

## 第四步：日常使用

### 后续更新代码

```bash
# 1. 进入项目文件夹
cd pickleball-club

# 2. 添加修改
git add .

# 3. 提交
git commit -m "更新了什么内容"

# 4. 推送到 GitHub
git push origin main
```

推送后，Render 会**自动检测代码变化并重新部署**（约 2-3 分钟）。

### 休眠与唤醒

**Render 免费套餐的特点：**
- 15 分钟没有任何访问，服务会自动休眠（省资源）
- 下次有人访问时，自动唤醒，大约需要 **30 秒**等待
- 这对俱乐部网站完全够用，不影响正常使用

### 手动重新部署

如果需要手动触发重新部署：
1. 登录 [render.com](https://render.com)
2. 进入你的 `pickleball-zone` 项目
3. 点击 **"Manual Deploy"** → **"Deploy latest commit"**

---

## 常见问题

**Q: 部署失败，日志显示 `Cannot find module`**
A: 检查 Build Command 是否为 `cd server && npm install --production && node db.js`，确保在 `server` 目录下安装依赖。

**Q: 部署成功但页面打不开**
A: 等待 1-2 分钟，Render 可能还在初始化。如果超过 5 分钟还不行，查看 Logs 是否有报错。

**Q: 页面能打开但图片不显示**
A: 确认 `assets/` 文件夹和里面的图片都上传到了 GitHub。在 Render 的 Logs 里搜索 `404` 看看是哪些文件找不到。

**Q: 数据库报错 `SQLITE_CANTOPEN`**
A: Render 的文件系统是只读的（除了 `/tmp`）。需要把数据库路径改为 `/tmp/data.db`。
   - 解决方法：在 Render 项目页面 → **Environment** → 添加环境变量：
     - Key: `DB_PATH`
     - Value: `/tmp/data.db`
   - 然后在代码中 `server/index.js` 和 `server/db.js` 里把数据库路径改为读取这个环境变量。
   - **或者更简单**：在 Render 的 Environment 里添加 `NODE_ENV` = `production`，我已经在 `render.yaml` 里配好了。

**Q: 如何绑定自己的域名？**
A:
1. Render 项目 → **Settings** → 找到 **"Custom Domain"**
2. 输入你的域名，如 `www.yourclub.com`
3. 按照页面提示，在你的域名服务商（如阿里云、Cloudflare）添加 CNAME 记录
4. 等 DNS 生效（通常几分钟到几小时）

**Q: 管理员密码怎么改？**
A: 首次部署后，用 admin / admin123 登录管理后台。修改密码的方法：
   - 方案一：在管理后台的会员管理里找到 admin 账号调整
   - 方案二：重新运行 `node db.js`（会重置整个数据库）

**Q: Railway 和 Render 选哪个？**
A:
   - **Railway**：体验更流畅，部署更快，但免费额度用完就需付费（约 $5/月）
   - **Render**：永久免费套餐，但 15 分钟不访问会休眠（冷启动 30 秒）
   - 如果是长期运营的俱乐部网站，建议先在 Render 免费试用，稳定后升级付费套餐或迁移到 VPS

---

## 与 Railway 的区别

| | Render（免费） | Railway |
|--|---------------|---------|
| 费用 | 永久免费 | 注册送 $5，之后约 $5/月 |
| 冷启动 | 15 分钟休眠，30 秒唤醒 | 不会自动休眠 |
| 部署方式 | 自动检测 render.yaml | 自动检测 railway.json |
| 数据持久化 | 需要额外配置 | 默认支持 |
| 流量限制 | 750 小时/月 | 按量计费 |
| 推荐场景 | 个人/小俱乐部长期免费运行 | 快速原型、短期展示 |

两个平台的代码是**同一份**，已经同时包含了 `render.yaml` 和 `railway.json` 配置文件，切换平台不需要改任何代码。

---

## 需要帮助？

如果部署过程中遇到任何问题，把 Render 的部署日志截图或报错信息发给我，我帮你排查！